# Brawlhalla AI — Android starter

This project is a real Android starter for an adaptive screen-control agent.

Architecture:
- MediaProjection: captures the screen after the user grants permission.
- AccessibilityService: dispatches touch gestures.
- Vision: lightweight local screen feature extraction.
- Agent: tabular Q-learning with epsilon-greedy exploration.
- Game mapping: starter normalized touch zones intended for Brawlhalla mobile.

Important:
- This is a foundation, not a finished competitive bot.
- The visual model is intentionally lightweight. For strong play, replace Vision.extract with a trained object-detection model and replace the action space with Brawlhalla-specific controls.
- The user must explicitly grant Android screen-capture and accessibility permissions.
- Use only where automation is permitted by the game's rules/platform.
