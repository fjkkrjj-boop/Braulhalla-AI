package com.example.brawlhallaai

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import kotlin.math.roundToInt

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun lp(width: Int, height: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            width, height,
            if (android.os.Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

    private fun showBubble() {
        bubble = TextView(this).apply {
            text = "AI"
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xCC202124.toInt())
            gravity = Gravity.CENTER
            setPadding(20, 12, 20, 12)
            setOnClickListener { showPanel() }
        }
        wm.addView(bubble, lp(72, 58))
    }

    private fun showPanel() {
        if (panel != null) return
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(0xEE171717.toInt())
        }
        val title = TextView(this).apply {
            text = "Brawlhalla AI"
            textSize = 19f
            setTextColor(Color.WHITE)
        }
        panel!!.addView(title)

        val start = Button(this).apply {
            text = "تشغيل AI"
            setOnClickListener {
                startService(Intent(this@OverlayService, AiService::class.java).setAction(AiService.START))
            }
        }
        val stop = Button(this).apply {
            text = "إيقاف AI"
            setOnClickListener {
                stopService(Intent(this@OverlayService, AiService::class.java))
            }
        }
        val close = Button(this).apply {
            text = "إخفاء اللوحة"
            setOnClickListener { hidePanel() }
        }
        panel!!.addView(start)
        panel!!.addView(stop)
        panel!!.addView(close)
        wm.addView(panel, lp(280, WindowManager.LayoutParams.WRAP_CONTENT))
    }

    private fun hidePanel() {
        panel?.let { wm.removeView(it) }
        panel = null
    }

    override fun onDestroy() {
        bubble?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
