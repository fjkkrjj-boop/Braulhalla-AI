package com.example.brawlhallaai

import android.content.*
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        box.addView(TextView(this).apply {
            text = "Brawlhalla AI"
            textSize = 28f
        })
        box.addView(TextView(this).apply {
            text = "\n1) فعّل التحكم من إمكانية الوصول.\n2) فعّل الظهور فوق التطبيقات الأخرى.\n3) اضغط تشغيل النافذة العائمة.\n4) افتح Brawlhalla واستخدم زر AI العائم."
            textSize = 16f
        })
        fun b(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { f() }
        }
        box.addView(b("إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        box.addView(b("السماح بالنافذة العائمة") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        box.addView(b("تشغيل AI العائم") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "فعّل صلاحية النافذة العائمة أولاً", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "زر AI العائم ظهر على الشاشة", Toast.LENGTH_SHORT).show()
            }
        })
        box.addView(b("إيقاف AI") {
            stopService(Intent(this, AiService::class.java))
            stopService(Intent(this, OverlayService::class.java))
        })
        setContentView(box)
    }
}
