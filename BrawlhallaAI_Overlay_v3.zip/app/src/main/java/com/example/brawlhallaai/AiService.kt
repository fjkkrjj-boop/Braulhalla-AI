package com.example.brawlhallaai

import android.app.*
import android.content.*
import android.graphics.Bitmap
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import kotlin.math.*
import kotlin.random.Random

class AiService : Service() {
    companion object {
        const val START = "START"
        var projectionResult: Int = 0
        var projectionData: Intent? = null
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var loop: Handler? = null
    private var lastAction = -1
    private var epsilon = 0.20
    private val q = HashMap<String, DoubleArray>()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notification = Notification.Builder(this, "ai")
            .setContentTitle("Brawlhalla AI")
            .setContentText("Adaptive agent running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(7, notification)
        }
        if (projectionData != null) startCapture()
        return START_STICKY
    }

    private fun startCapture() {
        val mgr = getSystemService(MediaProjectionManager::class.java)
        projection = mgr.getMediaProjection(projectionResult, projectionData!!)
        // Capture dimensions are deliberately conservative; actual device size is obtained from display metrics.
        val dm = resources.displayMetrics
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        projection!!.createVirtualDisplay("BrawlhallaAI", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            0, reader!!.surface, null, null)

        loop = Handler(Looper.getMainLooper())
        loop!!.post(object : Runnable {
            override fun run() {
                reader?.acquireLatestImage()?.use { image ->
                    val plane = image.planes[0]
                    val bmp = Bitmap.createBitmap(dm.widthPixels, dm.heightPixels, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(plane.buffer)
                    val features = Vision.extract(bmp)
                    val state = features.stateKey
                    val action = Agent.choose(state, q, epsilon)
                    perform(action, dm.widthPixels.toFloat(), dm.heightPixels.toFloat())
                    Agent.learn(q, state, action, features.reward, state, 0.12)
                    epsilon = max(0.05, epsilon * 0.9995)
                    bmp.recycle()
                }
                loop?.postDelayed(this, 120)
            }
        })
        loop!!.postDelayed(loop!!.looper?.let { Runnable {} } ?: Runnable {}, 120)
    }

    private fun perform(action: Int, w: Float, h: Float) {
        val s = GameAccessibilityService.instance ?: return
        // Safe starter mapping: tap zones. Coordinates are normalized so the policy works across phones.
        when (action) {
            0 -> {}                       // neutral
            1 -> s.tap(w * .18f, h * .80f) // left
            2 -> s.tap(w * .30f, h * .80f) // right
            3 -> s.tap(w * .76f, h * .80f) // jump/attack starter
            4 -> s.tap(w * .88f, h * .80f) // attack
            5 -> s.tap(w * .88f, h * .68f) // dodge/up
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("ai", "Brawlhalla AI", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy() {
        loop?.removeCallbacksAndMessages(null)
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}

data class VisionFeatures(val stateKey: String, val reward: Double)

object Vision {
    fun extract(b: Bitmap): VisionFeatures {
        // Lightweight screen descriptor. This intentionally avoids OCR/game-specific assets.
        val w = b.width
        val h = b.height
        val sample = 12
        var bright = 0
        var edge = 0
        var prev = 0
        for (y in 0 until h step max(1, h / sample)) {
            for (x in 0 until w step max(1, w / sample)) {
                val p = b.getPixel(x, y)
                val v = ((p shr 16 and 255) + (p shr 8 and 255) + (p and 255)) / 3
                if (v > 170) bright++
                if (abs(v - prev) > 80) edge++
                prev = v
            }
        }
        val state = "${bright / 8}:${edge / 8}"
        val reward = (edge / 20.0).coerceIn(-1.0, 1.0)
        return VisionFeatures(state, reward)
    }
}

object Agent {
    fun choose(state: String, q: HashMap<String, DoubleArray>, epsilon: Double): Int {
        val values = q.getOrPut(state) { DoubleArray(6) }
        if (Random.nextDouble() < epsilon) return Random.nextInt(values.size)
        var best = 0
        for (i in 1 until values.size) if (values[i] > values[best]) best = i
        return best
    }
    fun learn(q: HashMap<String, DoubleArray>, state: String, action: Int,
              reward: Double, next: String, alpha: Double) {
        val cur = q.getOrPut(state) { DoubleArray(6) }
        val nxt = q.getOrPut(next) { DoubleArray(6) }
        val target = reward + 0.92 * nxt.maxOrNull()!!
        cur[action] += alpha * (target - cur[action])
    }
}
